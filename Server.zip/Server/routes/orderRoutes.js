const express = require("express");
const router = express.Router();

const {
  createOrder,
  getMyOrders,
  getAllOrders,
  markOrderPaid,
  markOrderDelivered,
} = require("../Controllers/orderController");

const { protect, adminOnly } = require("../Middlewares/authMiddleware");

router.post("/", protect, createOrder);
router.get("/myorders", protect, getMyOrders);

router.get("/", protect, adminOnly, getAllOrders);
router.put("/:id/pay", protect, adminOnly, markOrderPaid);
router.put("/:id/deliver", protect, adminOnly, markOrderDelivered);

module.exports = router;
