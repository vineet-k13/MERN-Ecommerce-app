const express = require("express");
const router = express.Router();

const {
  createProduct,
  getProducts,
  getProductById,
} = require("../Controllers/productController");

const { protect, adminOnly } = require("../middlewares/authMiddleware");

// ADMIN
router.post("/", protect, adminOnly, createProduct);

// PUBLIC
router.get("/", getProducts);
router.get("/:id", getProductById);

module.exports = router;
