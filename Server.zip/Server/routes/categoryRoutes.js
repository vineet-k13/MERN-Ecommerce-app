const express = require("express");
const router = express.Router();

const {
  createCategory,
  getCategories,
} = require("../Controllers/CategoryController");

const { protect, adminOnly } = require("../middlewares/authMiddleware");

router.post("/", protect, adminOnly, createCategory);

router.get("/", getCategories);

module.exports = router;
